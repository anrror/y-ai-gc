# dsh-aigc-video

**DSH plugin** (DeepSeek Harness): AI video generation pipeline (script → character → storyboard → reference → video → edit) plus video mixing (混剪) and smart editing (智剪).

Runs **inside** a DSH process on port 3080 — the desktop shell `dsh-client-shell` (Tauri/Rust) embeds DSH which loads this plugin. Also spawns its own Node `http` server on port 8000 with the Python AIGC-Claw backend's API contract, so OpenClaw Agent + dsh-shell tooling can keep calling `http://localhost:8000/api/project/...` without any change.

## 4 model-facing tools

| Tool | Status | What it does |
|---|---|---|
| `aigc_video_generate` | ✅ real (Hailuo v1/v2 verified end-to-end) | Single-clip generation via MiniMax Hailuo v1 (file_id) and v2 (content[]). 79.8 s smoke test produced 2.65 MiB MP4. |
| `aigc_mix` | ✅ real (requires ffmpeg on PATH) | 8 transitions (crossfade / dip-to-black/white / iris / wipe / push / barn / clock), BGM mix, SRT subtitle burn-in via ffmpeg subprocess. |
| `aigc_smart_edit` | ✅ real (heuristic) | Scene-detect + silencedetect + script↔transcript Jaccard alignment + heuristic scoring. Whisper transcripts land in 6.5. |
| `aigc_pipeline_run` | ✅ real (all 6 agents) | End-to-end orchestrator: `PipelineOrchestrator` + `StateMachine` + `SessionManager` (atomic JSON). All 6 concrete stage agents registered via `registerAllAgents`. Pipeline runs as far as configured providers allow; missing providers stop the pipeline gracefully (not an error). |

## Architecture

```
src/
├── index.ts                       # apply(ctx: Context) — registers 4 tools + spawns HTTP server
├── framework/streaming.ts         # SSEEvent class (NDJSON wire format)
├── providers/                     # Phase 2 — LLM/Image/Video/VLM clients
│   ├── config.ts                  # config.yaml + .env loader (camelizes snake_case keys)
│   ├── base.ts                    # HttpClient + BaseProvider
│   ├── types.ts                   # LLMProvider/ImageProvider/VideoProvider/VlmProvider
│   ├── video/hailuo.ts            # MiniMax v1 (POST /v1/video_generation) + v2 (POST /v2/video_generation)
│   ├── video/index.ts             # createVideoProvider (Kling/Wan/Hailuo/SelfHost stubs)
│   ├── llm/index.ts               # OpenAI-compatible base + DeepSeek/Qwen/GLM/Kimi/Isigning/Minimax
│   ├── image/index.ts             # Wan/Jimeng/Seedream stubs
│   └── vlm/index.ts               # Qwen-VL/Gemini-VL stubs
├── pipeline/                      # Phase 4 — orchestrator
│   ├── types.ts                   # StageName, STAGES, StageStatus, StateMachine
│   ├── session.ts                 # SessionManager (atomic JSON write, ESM-only)
│   ├── base_agent.ts              # BaseAgent trait (Phase 4.5: optional LLM/image/video deps)
│   └── orchestrator.ts            # PipelineOrchestrator (run + continue + intervene + registerAllAgents)
├── agents/                        # Phase 4.5 — all 6 concrete stage agents
│   ├── script_writer.ts           # ScriptWriterAgent (LLM, JSON extract)
│   ├── character_designer.ts      # CharacterDesignerAgent (LLM)
│   ├── storyboard.ts              # StoryboardAgent (LLM)
│   ├── reference_generator.ts     # ReferenceGeneratorAgent (Image)
│   ├── video_director.ts          # VideoDirectorAgent (Video — Hailuo)
│   └── editor.ts                  # EditorAgent (LLM, generates SRT)
├── video/                         # Phase 5 — ffmpeg mixing
│   ├── ffmpeg.ts                  # FfmpegRunner (subprocess + ffprobe + download)
│   ├── transitions.ts             # 8 transition kinds → xfade name
│   └── mixer.ts                   # VideoMixer (xfade chain + BGM + subtitles)
├── audio/                         # Phase 6/7 — audio analysis
│   ├── scene_detect.ts            # ffmpeg scene= filter
│   ├── vad.ts                     # ffmpeg silencedetect
│   └── beats.ts                   # ffmpeg astats + peak-picking
├── smart/                         # Phase 6 — smart editing
│   ├── align.ts                   # Jaccard bigram script ↔ transcript alignment
│   ├── score.ts                   # Heuristic scoring (4-factor)
│   └── decide.ts                  # EditDecision JSON assembly
├── http/
│   └── server.ts                  # Phase 8 — 10-endpoint Node http server (port 8000)
└── tools/                         # Model-facing tool wrappers
    ├── video_generate.ts          # wires HailuoVideoProvider
    ├── mix.ts                     # wires VideoMixer
    ├── smart_edit.ts              # wires scene_detect + vad + decide
    └── pipeline.ts                # wires PipelineOrchestrator + registerAllAgents
```

## Installation

```bash
# 1. Build
npm install
npm run build

# 2. Run standalone smoke tests
node smoke.mjs                # Phase 2 verified: end-to-end Hailuo v1 → MP4 (consumes 1 quota)
node smoke-http.mjs           # Phase 8 verified: 12/12 HTTP endpoint tests

# 3. Install into DSH (once a DSH runtime is available)
dsh plugin add ./dsh-aigc-video
pnpm dsh web --patch ./dsh-aigc-video/cordis.patch.yml
```

DSH startup log should print:
```
[dsh-aigc-video] plugin loaded; tools registered: aigc_video_generate, aigc_mix, aigc_smart_edit, aigc_pipeline_run
[dsh-aigc-video] HTTP server listening on http://127.0.0.1:8000 (10 endpoints)
```

## HTTP server (Phase 8)

The plugin starts a Node `http` server on `127.0.0.1:8000` automatically inside `apply()`. It mirrors the Python AIGC-Claw backend's API contract, so the OpenClaw Agent (SKILL.md) and `dsh-client-shell` UI keep working without any change. Endpoints:

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | Health probe |
| GET | `/api/stages` | List of 6 pipeline stages |
| POST | `/api/project/create` | Allocate a new session |
| POST | `/api/project/start` | Allocate + apply caller-supplied meta |
| GET | `/api/project/{id}` | Read full session JSON |
| GET | `/api/project/{id}/status` | Status summary (current stage, completed, etc.) |
| GET | `/api/project/{id}/artifact/{stage}` | Read a stage's persisted artefact |
| POST | `/api/project/{id}/execute/{stage}` | Run the stage and stream NDJSON progress |
| POST | `/api/project/{id}/intervene` | Record a user modification at a stop-point |
| POST | `/api/project/{id}/continue` | Advance the state machine after a stop-point |

Set `AIGC_HTTP_DISABLED=1` in the DSH runtime environment to skip spawning the server.

## Configuration

`config.yaml` (project root or CWD) — same schema as the Python AIGC-Claw backend:

```yaml
server:
  host: 127.0.0.1
  port: 8000
session:
  data_dir: code/data
pipeline:
  video_provider: hailuo-2.3     # used by aigc_video_generate
  planner_enabled: false
  planner_model: isigning-llm     # used by aigc_pipeline_run
  models:
  wan:
    # DashScope 通义图像生成 (wanx-v1). ReferenceGeneratorAgent 用。
    api_key: ${DASHSCOPE_API_KEY}
    base_url: "https://dashscope.aliyuncs.com/api/v1"
    concurrency: 2
    model_name: "wanx-v1"
  hailuo-2.3:
    api_key: ${MINIMAX_API_KEY}
    base_url: https://api.minimaxi.com    # China station
    model_name: MiniMax-Hailuo-2.3
    concurrency: 3
  minimax-h3:                    # alias for Hailuo v2 (auto-routes to v2 endpoint)
    api_key: ${MINIMAX_API_KEY}
    base_url: https://api.minimaxi.com
    model_name: MiniMax-H3
    concurrency: 2
  isigning-llm:
    api_key: ${ISIGNING_API_KEY}
    base_url: https://prod-ai.isigning.cn/v1
    concurrency: 5
```

Environment variable `${MINIMAX_API_KEY}` is expanded at lookup time from the process environment. The plugin loads `config.yaml` lazily on first tool call; edit-and-restart is enough.

## Status (vs design doc `4-DSH插件架构设计.md`)

| Phase | Scope | Status |
|---|---|---|
| 1 | Plugin skeleton (`apply(ctx)` + 4 stub tools) | ✅ |
| 2 | Providers (LLM/Image/Video/VLM TypeScript clients) | ✅ Hailuo v1/v2 verified end-to-end against real MiniMax API (Token Plan, 79.8 s smoke); LLM base class complete; Image/VLM stubs |
| 3 | Tools — `aigc_video_generate` real | ✅ uses HailuoVideoProvider |
| 4 | 6-stage pipeline (StateMachine + SessionManager + Orchestrator + **all 6 concrete agents** + `aigc_pipeline_run`) | ✅ **all 6 agents implemented** (script_writer / character_designer / storyboard / reference_generator / video_director / editor); `registerAllAgents(deps)` wires them all; pipeline runs end-to-end when all providers are configured |
| 5 | Video mixing (ffmpeg subprocess + 8 transitions + `aigc_mix`) | ✅ code complete; requires ffmpeg.exe on PATH (not bundled) |
| 6 | Smart editing (scene_detect + vad + align + score + decide + `aigc_smart_edit`) | ✅ heuristic; Whisper-node transcripts deferred to 6.5 |
| 7 | Beat sync + BGM (`audio/beats.ts`) | ✅ module written; integration into smart_edit deferred |
| **8** | **HTTP server** (10 endpoints, port 8000) | ✅ **plugin spawns its own Node http server**; 12/12 smoke tests pass. Workaround: instead of relying on a missing `ctx.http.mount` in `@deepseek-ai/cordis`, the plugin starts its own `node:http` server inside `apply()`. Set `AIGC_HTTP_DISABLED=1` to suppress. |
| 9 | Tests + docs | ✅ **18 tests across 7 files** (`align`/`wan_image`/`jimeng_image`/`video_generate`/`pipeline_run`/`mix`/`smart_edit`) + this README + `smoke-http.mjs` (12 tests) |
| 10 | Publish to npm + dsh-shell integration | 🟡 `npm pack` dry-run verified; live publish needs DSH integration in `dsh-client-shell` (out of scope here) |

## Known limitations

1. **ffmpeg not bundled** — the installer must either include ffmpeg.exe or instruct the user to install it (`winget install ffmpeg` on Windows, `apt install ffmpeg` on Linux, `brew install ffmpeg` on macOS).
2. **Whisper-node not integrated** — Phase 6 smart_edit falls back to scene-detect + VAD + script-match (no transcript alignment). Phase 6.5 will add `whisper-node` with model download on first launch.
3. **`reference_generation` requires `DASHSCOPE_API_KEY`** — the `wan` image provider is configured in `config.yaml` (DashScope 通义 wanx-v1) and `WanImageProvider.generate()` is implemented (async submit + poll + download). Set `DASHSCOPE_API_KEY` in your env to actually run reference_generation. Other image providers (Jimeng, Seedream) are still stubs.
4. **HTTP server may collide with other services on port 8000** — set `AIGC_HTTP_PORT` (planned for Phase 10).
5. **Python AIGC-Claw backend still kept for compatibility** — the OpenClaw Agent (SKILL.md) calls `http://localhost:8000/api/project/...`; this plugin now serves those endpoints natively (Phase 8), so the Python backend can be retired once dsh-shell integration is confirmed.
6. **DSH supports MiniMax via `dsh-llm-pi-ai`** (Phase 9.5). The plugin doesn't ship an LLM adapter — it instantiates providers directly. For DSH to use MiniMax as its main LLM, install `dsh-llm-pi-ai` separately and configure `MINIMAX_CN_API_KEY`.

## Development

```bash
npm install
npm run typecheck     # tsc --noEmit
npm run build         # outputs dist/
npm test              # vitest (18 tests across 7 files)
node smoke.mjs        # Phase 2 end-to-end smoke (real API, consumes quota)
node smoke-http.mjs   # Phase 8 HTTP smoke (12 tests, no real API)
```

Requires Node.js ≥ 22.15 (per DSH baseline). ffmpeg/ffprobe required on PATH for Phase 5/6/7 functionality.

## License

MIT.